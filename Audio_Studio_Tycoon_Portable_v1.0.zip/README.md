# Audio Studio Tycoon - Portable Version (v1.0-alpha)

> [!IMPORTANT]
> **HINWEIS**: Dieses Spiel befindet sich noch in der Entwicklung (Alpha-Phase). Es können Fehler auftreten und einige Features sind noch nicht finalisiert.

Audio Studio Tycoon ist eine 100% Screenreader-optimierte Management-Simulation, bei der du deine eigene Spielefirma gründest.

## Kurzanleitung
1. Entpacke alle Dateien in einen Ordner.
2. Starte das Spiel über die Datei `Audio Studio Tycoon.exe`.
3. Stelle sicher, dass dein Screenreader (z.B. NVDA) aktiv ist, um alle Sprachausgaben zu hören.

## Steuerung
- **Pfeiltasten**: Navigieren in Menüs und Slidern.
- **Enter**: Auswahl bestätigen.
- **Buchstaben/Zahlen**: Texteingabe für Firmen- und Spielnamen.
- **Esc**: Zurück zum vorherigen Menü (sofern verfügbar).

Viel Spaß beim Aufbau deines Imperiums!
